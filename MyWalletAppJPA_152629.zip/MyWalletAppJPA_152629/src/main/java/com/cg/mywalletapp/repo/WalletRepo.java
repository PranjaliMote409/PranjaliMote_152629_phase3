package com.cg.mywalletapp.repo;

import java.math.BigDecimal;
import java.util.List;

import com.cg.mywalletapp.beans.Customer;
import com.cg.mywalletapp.exception.InvalidInputException;

public interface WalletRepo {

	public void save(Customer customer);

	public Customer findOne(String mobileNo);

	public void updateWallet(String mobileNo, Customer customer);

	public void addTransactions(String mobileNo, String transaction);

	public List<String> printTransaction(String mobileNo);

	public void removeCustomer(Customer customer);

	public boolean checkMobileAvailable(String mobile) throws InvalidInputException;

	public void commitTransaction();

	public void beginTransaction();

}
