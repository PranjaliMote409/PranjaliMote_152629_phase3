package com.cg.mywalletapp.repo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;

import com.cg.mywalletapp.beans.Customer;
import com.cg.mywalletapp.exception.IMyException;
import com.cg.mywalletapp.exception.InvalidInputException;
import com.cg.mywalletapp.util.DBUtil;

public class WalletRepoImpl implements WalletRepo {
	Connection con = null;
	
	private EntityManager entityManager;

	public WalletRepoImpl() {
		try {
			con = DBUtil.getConnect();
			entityManager = JPAUtil.getEntityManager();
		} catch (Exception e) {

			e.printStackTrace();
		}
	}


	
	public Customer findOne(String mobileNo) {
		Customer customer = entityManager.find(Customer.class, mobileNo);
		return customer;
	}

	public void save(Customer customer) {

		entityManager.persist(customer);

	}

	public void updateWallet(String mobileNo, Customer customer) {
		entityManager.merge(customer);

	}

	public void addTransactions(String mobileNo, String transaction) {
		try {

			String sql = "INSERT into Print_transaction1 values(?,?)";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, mobileNo);
			pstmt.setString(2, transaction);
			pstmt.executeQuery();

		} catch (Exception e) {
		}

	}

	public List<String> printTransaction(String mobileNo) {
		List<String> myList = new ArrayList<String>();

		try {
			String sql = "Select *from Print_transaction1 where MOBILENO=?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, mobileNo);
			ResultSet res = pstmt.executeQuery();
			while (res.next()) {
				myList.add(res.getString(2));
			}

		} catch (Exception e) {

		}

		return myList;

	}

	public void removeCustomer(Customer customer) {
		entityManager.remove(customer);
	}

	public void beginTransaction() {
		entityManager.getTransaction().begin();

	}

	public void commitTransaction() {
		entityManager.getTransaction().commit();

	}
	public boolean checkMobileAvailable(String mobile) throws InvalidInputException {
		boolean result = false;
		String sql = "Select *from CustomerDetails where MOBILE_NUMBER=?";
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, mobile);
			ResultSet res = pstmt.executeQuery();

			if (res.next()) {
				result = true;
			}else {
				throw new InvalidInputException(IMyException.ERROR5);
			}
		} catch (SQLException e) {
			
		}

		return result;
	}



}
