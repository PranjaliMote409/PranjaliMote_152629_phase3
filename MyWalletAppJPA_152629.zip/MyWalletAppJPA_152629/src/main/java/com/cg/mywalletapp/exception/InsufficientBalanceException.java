package com.cg.mywalletapp.exception;

public class InsufficientBalanceException extends Exception{

	public InsufficientBalanceException(String msg) {
		super(msg);
	}

}
