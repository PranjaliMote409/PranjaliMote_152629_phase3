package com.cg.mywalletapp.exception;

public class InvalidInputException extends Exception{ 
	public InvalidInputException() {
		System.out.println("invalid input");
	}
	public InvalidInputException(String msg) {
		super(msg);
	}

}
